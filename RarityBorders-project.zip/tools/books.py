"""Генерирует обложки зачарованных книг под каждое зачарование + CIT-файлы (CIT Resewn)."""
import sys, os, json, numpy as np
from PIL import Image
src, out = sys.argv[1], sys.argv[2]
COLORS = json.load(open(os.path.join(os.path.dirname(__file__), 'enchant_colors.json'), encoding='utf-8'))
base = np.asarray(Image.open(src).convert('RGBA')).astype(float)
cover = {(101,75,23):1.0,(82,46,16):0.78,(68,37,10):0.64,(68,51,16):0.66,(84,62,19):0.84,(49,33,4):0.42,(22,16,5):0.2}
os.makedirs(out, exist_ok=True)
for ench, hexc in COLORS.items():
    c = np.array([int(hexc[i:i+2],16) for i in (1,3,5)], float)
    a = base.copy()
    for y in range(16):
        for x in range(16):
            k = tuple(int(v) for v in a[y,x,:3])
            if a[y,x,3] and k in cover:
                f = cover[k]
                a[y,x,:3] = np.clip(c * f * 0.95 + (8 if f > 0.5 else 0), 0, 255)
    name = ench.split(':')[1]
    Image.fromarray(a.astype(np.uint8), 'RGBA').save(os.path.join(out, name + '.png'))
    with open(os.path.join(out, name + '.properties'), 'w') as f:
        f.write(f"type=item\nitems=enchanted_book\ntexture={name}\nenchantmentIDs={ench}\n")
print(len(COLORS), 'books')
