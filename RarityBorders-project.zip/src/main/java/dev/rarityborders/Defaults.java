package dev.rarityborders;

import java.util.LinkedHashMap;
import java.util.Map;

/** Цвета зачарований по умолчанию (те же, что у обложек книг). */
final class Defaults {
	private Defaults() {
	}

	static final Map<String, String> ENCHANT_COLORS = new LinkedHashMap<>();

	static {
		Map<String, String> m = ENCHANT_COLORS;
		m.put("minecraft:protection", "#4A90E2");
		m.put("minecraft:fire_protection", "#FF7A1A");
		m.put("minecraft:feather_falling", "#DDEEFF");
		m.put("minecraft:blast_protection", "#8C8C8C");
		m.put("minecraft:projectile_protection", "#A0703C");
		m.put("minecraft:respiration", "#3FD0E0");
		m.put("minecraft:aqua_affinity", "#1FA8C9");
		m.put("minecraft:thorns", "#3CB043");
		m.put("minecraft:depth_strider", "#2563C9");
		m.put("minecraft:frost_walker", "#A8ECFF");
		m.put("minecraft:binding_curse", "#8B1A2B");
		m.put("minecraft:soul_speed", "#4AA3C7");
		m.put("minecraft:swift_sneak", "#6A4FC9");
		m.put("minecraft:sharpness", "#E03C31");
		m.put("minecraft:smite", "#F2E6A0");
		m.put("minecraft:bane_of_arthropods", "#7A5530");
		m.put("minecraft:knockback", "#C9C9C9");
		m.put("minecraft:fire_aspect", "#FF4500");
		m.put("minecraft:looting", "#FFD700");
		m.put("minecraft:sweeping", "#B0C4DE");
		m.put("minecraft:efficiency", "#FFC83D");
		m.put("minecraft:silk_touch", "#F7C6EC");
		m.put("minecraft:unbreaking", "#9A9A9A");
		m.put("minecraft:fortune", "#2ECC71");
		m.put("minecraft:power", "#D94A2B");
		m.put("minecraft:punch", "#B5651D");
		m.put("minecraft:flame", "#FF6A00");
		m.put("minecraft:infinity", "#B57BFF");
		m.put("minecraft:luck_of_the_sea", "#1ABC9C");
		m.put("minecraft:lure", "#3498DB");
		m.put("minecraft:loyalty", "#2F80ED");
		m.put("minecraft:impaling", "#00B3A4");
		m.put("minecraft:riptide", "#4FC3F7");
		m.put("minecraft:channeling", "#F7E55B");
		m.put("minecraft:multishot", "#E67E22");
		m.put("minecraft:quick_charge", "#F39C12");
		m.put("minecraft:piercing", "#A5B1B2");
		m.put("minecraft:mending", "#3CDC5A");
		m.put("minecraft:vanishing_curse", "#5B1A8C");
	}
}
