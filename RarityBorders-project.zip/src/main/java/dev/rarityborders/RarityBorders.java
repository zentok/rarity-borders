package dev.rarityborders;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Какие предметы получают рамку и какого цвета. */
public final class RarityBorders {
	private RarityBorders() {
	}

	public static final Logger LOG = LoggerFactory.getLogger("rarityborders");
	public static final ResourceLocation TEXTURE = new ResourceLocation("rarityborders", "textures/gui/border.png");

	/** true, пока рисуется предмет «на курсоре» — у него рамки нет. */
	public static boolean drawingCarried = false;

	public static String idOf(ItemStack stack) {
		return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
	}

	/** Цвет рамки 0xRRGGBB или -1, если рамка не нужна. */
	public static int colorFor(ItemStack stack) {
		if (stack.isEmpty()) return -1;
		BorderConfig cfg = BorderConfig.get();
		if (!cfg.enabled) return -1;
		// 1) свой цвет, выбранный игроком (работает для любых предметов)
		String own = cfg.items.get(idOf(stack));
		if (own != null) {
			int c = BorderConfig.parse(own);
			if (c == -2) return -1;
			if (c >= 0) return c;
		}
		// 2) зачарованная книга — цвет первого зачарования
		if (stack.getItem() instanceof EnchantedBookItem) {
			ListTag list = EnchantedBookItem.getEnchantments(stack);
			if (!list.isEmpty()) {
				String id = list.getCompound(0).getString("id");
				int c = BorderConfig.parse(cfg.enchantments.get(id));
				if (c >= 0) return c;
			}
			int c = BorderConfig.parse(cfg.bookDefault);
			return c >= 0 ? c : -1;
		}
		// 3) инструменты, оружие, еда, броня, зелья — без рамки
		if (cfg.skipToolsFoodArmorPotions && excluded(stack)) return -1;
		// 4) обычная редкость
		int c = switch (stack.getRarity()) {
			case UNCOMMON -> BorderConfig.parse(cfg.uncommon);
			case RARE -> BorderConfig.parse(cfg.rare);
			case EPIC -> BorderConfig.parse(cfg.epic);
			default -> -1;
		};
		return c >= 0 ? c : -1;
	}

	private static boolean excluded(ItemStack stack) {
		Item item = stack.getItem();
		return item instanceof TieredItem
				|| item instanceof ProjectileWeaponItem
				|| item instanceof TridentItem
				|| item instanceof ShearsItem
				|| item instanceof FishingRodItem
				|| item instanceof FlintAndSteelItem
				|| item instanceof ShieldItem
				|| item instanceof BrushItem
				|| item instanceof ArmorItem
				|| item instanceof ElytraItem
				|| item instanceof HorseArmorItem
				|| item instanceof PotionItem
				|| item instanceof TippedArrowItem
				|| item.isEdible();
	}
}
