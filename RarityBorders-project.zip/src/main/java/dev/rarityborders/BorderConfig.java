package dev.rarityborders;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * config/rarityborders.json — можно править руками.
 * items: "id предмета" -> "#RRGGBB" или "none" (без рамки). Свои цвета работают и для инструментов/еды/брони/зелий.
 * enchantments: цвет рамки зачарованной книги по первому зачарованию.
 */
public final class BorderConfig {
	public boolean enabled = true;
	public boolean skipToolsFoodArmorPotions = true;
	public String uncommon = "#FFFF55";
	public String rare = "#55FFFF";
	public String epic = "#FF55FF";
	public String bookDefault = "#AA55FF";
	public Map<String, String> items = new LinkedHashMap<>();
	public Map<String, String> enchantments = new LinkedHashMap<>();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static BorderConfig INSTANCE;
	private static long loadedStamp = -1;

	public static BorderConfig get() {
		if (INSTANCE == null) reload();
		return INSTANCE;
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("rarityborders.json");
	}

	/** Перечитать файл, если его изменили руками. */
	public static void reloadIfChanged() {
		try {
			Path p = path();
			if (Files.exists(p) && Files.getLastModifiedTime(p).toMillis() != loadedStamp) reload();
		} catch (Exception ignored) {
		}
	}

	public static void reload() {
		Path p = path();
		BorderConfig c = null;
		if (Files.exists(p)) {
			try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
				c = GSON.fromJson(r, BorderConfig.class);
			} catch (Exception e) {
				RarityBorders.LOG.warn("rarityborders.json is broken, using defaults: {}", e.toString());
			}
		}
		boolean fresh = c == null;
		if (fresh) c = new BorderConfig();
		if (c.items == null) c.items = new LinkedHashMap<>();
		if (c.enchantments == null) c.enchantments = new LinkedHashMap<>();
		if (fresh) c.items.put("minecraft:totem_of_undying", "#FFAA00");
		for (Map.Entry<String, String> e : Defaults.ENCHANT_COLORS.entrySet()) c.enchantments.putIfAbsent(e.getKey(), e.getValue());
		INSTANCE = c;
		if (fresh || !Files.exists(p)) save();
		try {
			loadedStamp = Files.getLastModifiedTime(p).toMillis();
		} catch (Exception ignored) {
		}
	}

	public static void save() {
		Path p = path();
		try {
			Files.createDirectories(p.getParent());
			try (Writer w = Files.newBufferedWriter(p, StandardCharsets.UTF_8)) {
				GSON.toJson(INSTANCE, w);
			}
			loadedStamp = Files.getLastModifiedTime(p).toMillis();
		} catch (Exception e) {
			RarityBorders.LOG.warn("Could not save rarityborders.json: {}", e.toString());
		}
	}

	/** "#RRGGBB" -> 0xRRGGBB, "none" -> -2 (явно без рамки), ошибка/пусто -> -1. */
	public static int parse(String s) {
		if (s == null) return -1;
		s = s.trim();
		if (s.equalsIgnoreCase("none") || s.equalsIgnoreCase("off")) return -2;
		if (s.startsWith("#")) s = s.substring(1);
		try {
			return Integer.parseInt(s, 16) & 0xFFFFFF;
		} catch (NumberFormatException e) {
			return -1;
		}
	}
}
