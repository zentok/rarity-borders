package dev.rarityborders;

import com.mojang.blaze3d.platform.InputConstants;
import dev.rarityborders.mixin.AbstractContainerScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

/**
 * Навёл мышку на предмет в инвентаре и нажал B — цвет рамки этого предмета меняется по кругу:
 * золотой → жёлтый → голубой → фиолетовый → красный → зелёный → синий → белый → без рамки → как было по умолчанию.
 */
public class RarityBordersClient implements ClientModInitializer {
	public static KeyMapping PICK;

	private static final String[] PALETTE = {"#FFAA00", "#FFFF55", "#55FFFF", "#FF55FF", "#FF5555", "#55FF55", "#5555FF", "#FFFFFF", "none", null};
	private static final String[] NAMES = {"золотая", "жёлтая", "голубая", "фиолетовая", "красная", "зелёная", "синяя", "белая", "без рамки", "по умолчанию"};

	@Override
	public void onInitializeClient() {
		BorderConfig.reload();
		PICK = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.rarityborders.pick", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.rarityborders"));
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (!(screen instanceof AbstractContainerScreen<?> acs)) return;
			BorderConfig.reloadIfChanged();
			ScreenKeyboardEvents.afterKeyPress(screen).register((scr, key, scancode, mods) -> {
				if (!PICK.matches(key, scancode)) return;
				Slot slot = ((AbstractContainerScreenAccessor) acs).getRbHoveredSlot();
				if (slot == null || !slot.hasItem()) return;
				cycle(slot.getItem());
			});
		});
	}

	private static void cycle(ItemStack stack) {
		BorderConfig cfg = BorderConfig.get();
		String id = RarityBorders.idOf(stack);
		String cur = cfg.items.get(id);
		int idx = PALETTE.length - 1; // «по умолчанию» = нет записи
		for (int i = 0; i < PALETTE.length - 1; i++) if (PALETTE[i].equalsIgnoreCase(cur == null ? "" : cur)) idx = i;
		if (cur != null && idx == PALETTE.length - 1) idx = -1; // свой цвет из файла — начинаем с первого
		int next = (idx + 1) % PALETTE.length;
		if (PALETTE[next] == null) cfg.items.remove(id);
		else cfg.items.put(id, PALETTE[next]);
		BorderConfig.save();
		Minecraft mc = Minecraft.getInstance();
		SystemToast.addOrUpdate(mc.getToasts(), SystemToast.SystemToastIds.NARRATOR_TOGGLE,
				Component.literal("Рамка: " + NAMES[next]), stack.getHoverName());
	}
}
