package dev.rarityborders.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.rarityborders.RarityBorders;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Все предметы в интерфейсе (инвентарь, хотбар, сундуки) рисуются через этот метод — рамку кладём под предмет. */
@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsMixin {
	@Inject(method = "renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;IIII)V",
			at = @At("HEAD"))
	private void rarityborders$drawBorder(LivingEntity entity, Level level, ItemStack stack, int x, int y, int seed, int guiOffset, CallbackInfo ci) {
		if (RarityBorders.drawingCarried) return;
		int color = RarityBorders.colorFor(stack);
		if (color < 0) return;
		GuiGraphics g = (GuiGraphics) (Object) this;
		float r = ((color >> 16) & 0xFF) / 255f, gr = ((color >> 8) & 0xFF) / 255f, b = (color & 0xFF) / 255f;
		RenderSystem.enableBlend();
		g.setColor(r, gr, b, 1f);
		g.blit(RarityBorders.TEXTURE, x, y, 0, 0, 16, 16, 16, 16);
		g.setColor(1f, 1f, 1f, 1f);
	}
}
