package dev.rarityborders.mixin;

import dev.rarityborders.RarityBorders;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Предмет на курсоре — без рамки. */
@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {
	@Inject(method = "renderFloatingItem", at = @At("HEAD"))
	private void rarityborders$carriedStart(GuiGraphics g, ItemStack stack, int x, int y, String text, CallbackInfo ci) {
		RarityBorders.drawingCarried = true;
	}

	@Inject(method = "renderFloatingItem", at = @At("RETURN"))
	private void rarityborders$carriedEnd(GuiGraphics g, ItemStack stack, int x, int y, String text, CallbackInfo ci) {
		RarityBorders.drawingCarried = false;
	}
}
